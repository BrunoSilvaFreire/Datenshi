#if UNITY_EDITOR
//-----------------------------------------------------------------------// <copyright file="SuffixLabelAttributeDrawer.cs" company="Sirenix IVS"> // Copyright (c) Sirenix IVS. All rights reserved.// </copyright>//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
// <copyright file="SuffixLabelAttributeDrawer.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using UnityEngine;
    using Sirenix.OdinInspector.Editor;
    using Sirenix.Utilities.Editor;
    using Sirenix.Utilities;

    /// <summary>
    /// Draws properties marked with <see cref="SuffixLabelAttribute"/>.
    /// </summary>
    /// <seealso cref="LabelTextAttribute"/>
    /// <seealso cref="PropertyTooltipAttribute"/>
    /// <seealso cref="InlineButtonAttribute"/>
    /// <seealso cref="CustomValueDrawerAttribute"/>

    [AllowGUIEnabledForReadonly]
    [DrawerPriority(DrawerPriorityLevel.WrapperPriority)]
    public sealed class SuffixLabelAttributeDrawer : OdinAttributeDrawer<SuffixLabelAttribute>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var property = this.Property;
            var attribute = this.Attribute;

            PropertyContext<StringMemberHelper> context;
            if (property.Context.Get(this, "SuffixContext", out context))
            {
                context.Value = new StringMemberHelper(property.FindParent(p => p.Info.HasSingleBackingMember, true).ParentType, attribute.Label);
            }

            if (attribute.Overlay)
            {
                this.CallNextDrawer(label);
                GUIHelper.PushGUIEnabled(true);
                GUI.Label(GUILayoutUtility.GetLastRect().HorizontalPadding(0, 8), context.Value.GetString(property), SirenixGUIStyles.RightAlignedGreyMiniLabel);
                GUIHelper.PopGUIEnabled();
            }
            else
            {
                GUILayout.BeginHorizontal();
                GUILayout.BeginVertical();
                this.CallNextDrawer(label);
                GUILayout.EndVertical();
                GUIHelper.PushGUIEnabled(true);
                GUILayout.Label(context.Value.GetString(property), SirenixGUIStyles.RightAlignedGreyMiniLabel, GUILayoutOptions.ExpandWidth(false));
                GUIHelper.PopGUIEnabled();
                GUILayout.EndHorizontal();
            }
        }
    }
}
#endif